﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'hr', {
	copy: 'Autorsko pravo &copy; $1. Sva prava pridržana.',
	dlgTitle: 'O CKEditoru 4',
	moreInfo: 'Za informacije o licencama posjetite našu web stranicu:'
} );
